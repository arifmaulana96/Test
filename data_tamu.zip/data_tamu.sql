-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2021 at 11:59 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buku_tamu`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_tamu`
--

CREATE TABLE `data_tamu` (
  `nama` varchar(20) NOT NULL,
  `nohp` char(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `pesan` varchar(20) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_tamu`
--

INSERT INTO `data_tamu` (`nama`, `nohp`, `email`, `pesan`, `tanggal`) VALUES
('anan abdul azis', '081213841716', 'ananabdul@gmail.com', 'Selamat Siang', '2021-03-25'),
('andi yohanes', '081296002201', 'andiyoh@gmail.com', 'Selamat sore', '2021-03-25'),
('ganjar sutanto', '082181892460', 'ganjarsutanto@gmail.', 'selamat malam', '2021-03-25'),
('angga hestu laksono', '08951954444', 'anggarock@gmail.com', 'selamat sore', '2021-03-25'),
('arif maulana', '08983448113', 'arifmaulanaaa96@gmai', 'Hallo selamat siang', '2021-03-25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_tamu`
--
ALTER TABLE `data_tamu`
  ADD PRIMARY KEY (`nohp`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
